<?php include 'includes/header.php'; ?>
<main>
  <section>
    <h1>Welcome to Esports Team</h1>
    <p>The ultimate gaming destination!</p>
  </section>
</main>
<?php include 'includes/footer.php'; ?>