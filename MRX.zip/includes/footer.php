<footer>
    <p>&copy; 2024 Esports Team. All rights reserved.</p>
  </footer>
</body>
</html>