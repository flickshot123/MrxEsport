<?php include 'includes/header.php'; ?>
<main>
  <section>
    <h1>About Us</h1>
    <p>We are a professional esports team competing globally.</p>
  </section>
</main>
<?php include 'includes/footer.php'; ?>